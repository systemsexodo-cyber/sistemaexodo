// Este arquivo está depreciado. Use lib/clientes_page.dart
export '../clientes_page.dart';
