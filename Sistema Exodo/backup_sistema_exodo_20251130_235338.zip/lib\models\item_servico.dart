class ItemServico {
  final String id;
  final String descricao;
  final double valor;

  ItemServico({required this.id, required this.descricao, required this.valor});

  factory ItemServico.fromMap(Map<String, dynamic> map) {
    return ItemServico(
      id: map['id'] ?? '',
      descricao: map['descricao'] ?? '',
      valor: (map['valor'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() {
    return {'id': id, 'descricao': descricao, 'valor': valor};
  }
}
