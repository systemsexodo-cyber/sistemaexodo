package com.example.sistema_exodo_novo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
